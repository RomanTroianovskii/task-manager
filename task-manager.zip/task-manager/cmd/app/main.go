package main

import (
	"github.com/RomanTroianovskii/task-manager/internal/api"
	"github.com/RomanTroianovskii/task-manager/internal/db"
	"github.com/RomanTroianovskii/task-manager/internal/middleware"

	"github.com/gin-gonic/gin"
)

func main() {
	// Инициализация БД (db.Init делает AutoMigrate для моделей User/Task)
	db.Init()

	r := gin.Default()

	// public
	r.POST("/register", api.Register)
	r.POST("/login", api.Login)

	// protected (пример)
	protected := r.Group("/api")
	protected.Use(middleware.JWTAuthMiddleware())
	{
		// пока заглушка — заменишь на реальные хендлеры задач
		protected.GET("/me", func(c *gin.Context) {
			c.JSON(200, gin.H{
				"user_id":  c.GetUint("user_id"),
				"username": c.GetString("username"),
			})
		})
	}

	r.Run(":8080")
}
